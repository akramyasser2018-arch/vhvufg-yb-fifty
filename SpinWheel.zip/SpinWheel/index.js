const {
    Client,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("./config.json");

const client = new Client({ intents: 53608447 });

const pointsFilePath = path.join(__dirname, "data/points.json");
const invitesFilePath = path.join(__dirname, "data/invites.json");
const joiningFilePath = path.join(__dirname, "data/joining.json");

function readJSONFile(filePath) {
    return fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath, "utf8")) : {};
}

function writeJSONFile(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
}

function getRandomPrize(type) {
    const prizeList = config.prizes[type];
    if (!prizeList || prizeList.length === 0) return "No prize available";

    while (true) {
        let randomValue = Math.random();
        let cumulativeChance = 0;
        for (const prizeItem of prizeList) {
            cumulativeChance += prizeItem.chance;
            if (randomValue <= cumulativeChance) {
                return prizeItem.prize;
            }
        }
    }
}

client.once("ready", async () => {
    console.log(`Logged in as ${client.user.tag}!\nhttps:discord.gg/mythicservices`);
    const guild = client.guilds.cache.get(config.guildID);
    if (!guild) return console.log("Guild not found.");

    const guildInvites = await guild.invites.fetch();
    const inviteData = {};
    guildInvites.forEach(
        (invite) => (inviteData[invite.code] = invite.uses || 0),
    );
    writeJSONFile(invitesFilePath, inviteData);
});

client.on("guildMemberAdd", async (member) => {
    if (member.guild.id !== config.guildID) return;

    const pointsData = readJSONFile(pointsFilePath);
    const oldInvitesData = readJSONFile(invitesFilePath);
    const joiningData = readJSONFile(joiningFilePath);

    const updatedInvites = await member.guild.invites.fetch();
    const usedInvite = updatedInvites.find(
        (invite) => (invite.uses || 0) > (oldInvitesData[invite.code] || 0),
    );
    const logChannel = member.guild.channels.cache.get(config.inviteLogID);

    if (usedInvite?.inviter && !member.user.bot) {
        if (joiningData.includes(member.id)) {
            await logChannel?.send(`⚠️ <@${usedInvite.inviter.id}> invited <@${member.id}> before. No points awarded.`);
        } else {
            joiningData.push(member.id);
            writeJSONFile(joiningFilePath, joiningData);
            pointsData[usedInvite.inviter.id] =
                (pointsData[usedInvite.inviter.id] || 0) + 1;
            pointsData[member.id] = 0;
            await logChannel?.send(`🎯 <@${usedInvite.inviter.id}> invited <@${member.id}>. Total points: ${pointsData[usedInvite.inviter.id]}`);
            writeJSONFile(pointsFilePath, pointsData);
        }
    }

    const newInviteData = {};
    updatedInvites.forEach(
        (invite) => (newInviteData[invite.code] = invite.uses || 0));
    writeJSONFile(invitesFilePath, newInviteData);
});

client.on("guildMemberRemove", (member) => {
    if (member.guild.id !== config.guildID) return;
    const pointsData = readJSONFile(pointsFilePath);
    delete pointsData[member.id];
    writeJSONFile(pointsFilePath, pointsData);
});

client.on("messageCreate", async (message) => {
    if (message.author.bot || message.guild?.id !== config.guildID) return;
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    const pointsData = readJSONFile(pointsFilePath);

    function savePointsData() {
        writeJSONFile(pointsFilePath, pointsData);
    }

    if (commandName === "add-points") {
        if (!message.member.roles.cache.some((role) => config.adminRolesID.includes(role.id)))
            return await message.reply("You don't have permission to use this command.");
        const targetMember = message.mentions.members.first();
        const pointsToAdd = parseInt(args[1]);
        if (!targetMember || isNaN(pointsToAdd))
            return await message.reply(`❌ Usage: \`${config.prefix}add-points @user amount\``);

        pointsData[targetMember.id] =
            (pointsData[targetMember.id] || 0) + pointsToAdd;
        savePointsData();
        await message.reply(`✅ Added ${pointsToAdd} points to <@${targetMember.id}>. Total: ${pointsData[targetMember.id]}`);
    }

    if (commandName === "remove-points") {
        if (!message.member.roles.cache.some((role) => config.adminRolesID.includes(role.id)))
            return await message.reply("You don't have permission to use this command.");
        const targetMember = message.mentions.members.first();
        const pointsToRemove = parseInt(args[1]);
        if (!targetMember || isNaN(pointsToRemove))
            return await message.reply(`❌ Usage: \`${config.prefix}remove-points @user amount\``);

        pointsData[targetMember.id] = Math.max(
            (pointsData[targetMember.id] || 0) - pointsToRemove,
            0,
        );
        savePointsData();
        await message.reply(`✅ Removed ${pointsToRemove} points from <@${targetMember.id}>. Total: ${pointsData[targetMember.id]}`);
    }

    if (commandName === "points") {
        const targetMember = message.mentions.members.first() || message.member;
        await message.reply(`📊 <@${targetMember.id}> has ${pointsData[targetMember.id] || 0} points.`);
    }

    if (commandName === "top-points") {
        const sortedPoints = Object.entries(pointsData)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)
            .filter(([, points]) => points > 0);
        if (sortedPoints.length === 0)
            return await message.reply("No users with points yet.");
        const leaderboard = sortedPoints
            .map(
                ([userId, points], index) =>
                    `${index + 1}. <@${userId}> - ${points} points`,
            )
            .join("\n");

        message.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle("🏆 Top Points Leaderboard 🏆")
                    .setColor(config.color)
                    .setDescription(leaderboard),
            ],
        });
    }

    if (commandName === "help") {
        message.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle("🤖 Bot Commands Help")
                    .setColor(config.color)
                    .addFields(
                        {
                            name: `${config.prefix}points [@user]`,
                            value: "Check your or another user's points",
                        },
                        {
                            name: `${config.prefix}spin`,
                            value: "Spin the wheel to win prizes",
                        },
                        {
                            name: `${config.prefix}top-points`,
                            value: "Show top 10 users with most points",
                        },
                        {
                            name: `${config.prefix}add-points @user amount`,
                            value: "Add points to a user (Admin only)",
                        },
                        {
                            name: `${config.prefix}remove-points @user amount`,
                            value: "Remove points from a user (Admin only)",
                        },
                    ),
            ],
        });
    }

    if (commandName === "spin") {
        const buttonsRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("normal_spin")
                .setLabel("Normal Spin")
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId("super_spin")
                .setLabel("Super Spin")
                .setStyle(ButtonStyle.Danger),
        );

        message.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle("🎉 Spin the Wheel 🎉")
                    .setDescription("🎡 Normal Spin: 1 point\n🔥 Super Spin: 2 points")
                    .setColor(config.color),
            ],
            components: [buttonsRow],
        });
    }
});

client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton() || interaction.guild?.id !== config.guildID)
        return;
    const pointsData = readJSONFile(pointsFilePath);
    const userPoints = pointsData[interaction.user.id] || 0;
    const prizeLogChannel = interaction.guild.channels.cache.get(
        config.prizeLogID,
    );

    async function handleSpin(cost, spinType) {
        if (userPoints < cost)
            return await interaction.reply("❌ Not enough points.");
        await interaction.deferReply();
        setTimeout(async () => {
            pointsData[interaction.user.id] = userPoints - cost;
            writeJSONFile(pointsFilePath, pointsData);
            const prize = getRandomPrize(spinType);
            await prizeLogChannel?.send(`🥳 <@${interaction.user.id}> won **${prize}** 🏆`);
            await interaction.editReply(`🎉 You won **${prize}**! 🏆`);
        }, 3000);
    }

    if (interaction.customId === "normal_spin") handleSpin(1, "normal");
    if (interaction.customId === "super_spin") handleSpin(2, "super");
});

client.login(config.token);

process.on("unhandledRejection", console.error);
process.on("uncaughtException", console.error);